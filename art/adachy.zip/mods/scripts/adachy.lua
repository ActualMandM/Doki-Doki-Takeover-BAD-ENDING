function onEvent(name)
	if name == 'Eye Popup' then
		playSound('adachy');
	end
end
